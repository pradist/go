package main

import (
	adx "ad/ad"
	"fmt"
)

func main() {
	cfg := &adx.Config{
		Server:   "172.30.137.212",
		Port:     "636",
		Security: adx.SecurityTLS,
		User:     "sanit.v_ocptest@kbankpocnet.com",
		Password: "P@ssw0rd",
		BaseDN:   "OU=TEST,DC=kbankpocnet,DC=com",
	}
	adClient, _, err := adx.NewClient("test", cfg)()
	if err != nil {
		panic(err)
	}
	_, _, err = adClient.Authenticate("sanit.v_ocptest@kbankpocnet.com", "P@ssw0rd")
	if err != nil {
		panic(err)
	}

	user, err := adClient.FindInfo("userPrincipalName", "sanit.v_ocptest@kbankpocnet.com")
	//user, err := adClient.FindInfo("sAMAccountName", "apimtest01.v_ocptest")

	if err != nil {
		panic(err)
	}


	for key, value := range user {
		fmt.Println("Key:", key, "Value:", value)
	}

}
